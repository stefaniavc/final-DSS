const Usuario = require("../models/Usuario");
const { verificarToken } = require("./token");

const verificarRol = (roles) => async (req, res, next) => {
  try {
    const token = req.headers.authorization.split(" ").pop();
    const tokenData = await verificarToken(token);
    const usuario = await Usuario.findById(tokenData._id);
    if ([].concat(roles).includes(usuario.rol)) {
      next();
    } else {
      return res.status(400).send({ error: "NO tienes permisos" });
    }
  } catch (e) {
    return res.status(400).send({ error: "Error en la peticion" });
  }
};

module.exports = verificarRol;
