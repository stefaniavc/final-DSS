const bcrypt = require('bcrypt')

const encriptar = async (textoPlano) => {
  const hash = await bcrypt.hash(textoPlano, 10)
  return hash
}

const comparar = async (contrasenaPlana, contrasenaHash) => {
  return await bcrypt.compare(contrasenaPlana, contrasenaHash)
}

module.exports = { encriptar, comparar }
