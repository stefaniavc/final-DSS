const validarUsuarios = (req) => {
    const validaciones = [];

    if (!req.body.nombre) {
        validaciones.push('Nombre requerido');
    }

    if (!req.body.email) {
        validaciones.push('Email requerido');
    }

    if (!req.body.estado) {
        validaciones.push('Estado requerido');
    }

    if (!req.body.fechaCreacion) {
        validaciones.push('Fecha de creación requerida');
    }

    if (!req.body.contrasena) {
        validaciones.push('Contraseña requerida')
    }

    if (!req.body.rol) {
        validaciones.push('Rol requerido')
    }

    if (req.body.rol !== 'Docente' || req.body.rol !== 'Administrador') {
        validaciones.push('Rol no permitido')
    }

    return validaciones;
}

module.exports = {
    validarUsuarios,
}