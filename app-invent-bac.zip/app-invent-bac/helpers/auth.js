const Usuario = require("../models/Usuario");
const { comparar } = require("./encriptar-contrasena");
const { tokenSign, verificarToken } = require("./token");

const auth = async (req, res) => {
  const { email, contrasena } = req.body;
  const usuario = await Usuario.find({ email });

  if (!usuario) {
    return res.status(404).send({ error: "Usuario no encontrado" });
  }

  const verificarContrasena = await comparar(contrasena, usuario.contrasena);
  const tokenSesion = await tokenSign(usuario);

  if (!verificarContrasena) {
    return res.status(400).send({ error: "Usuario o contraseña incorrectos" });
  }

  return res.status(200).send({ data: usuario, tokenSesion });
};

const checkAuth = async (req, res, next) => {
  try {
    const token = req.headers.authorization.split(" ").pop();
    const tokenData = await verificarToken(token);
    if (tokenData._id) {
      next();
    } else {
      res.status(400).send({ error: "No puedes pasar" });
    }
  } catch (e) {
    res.status(400).send({ error: "Error en la peticion" });
  }
};

module.exports = {
  auth,
  checkAuth
};
