module.exports = {
  docente: "Docente",
  administrador: "Administrador"
}