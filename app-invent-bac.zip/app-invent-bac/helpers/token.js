const jwt = require("jsonwebtoken");

const secret = process.env.SECRET;

const tokenSign = async (user) => {
  return jwt.sign(
    {
      _id: user.usuarioId,
      rol: user.rol,
    },
    secret,
    {
      expiresIn: "2h",
    }
  );
};

const verificarToken = async (token) => {
  try {
    return jwt.verify(token, secret)
  } catch (e) {
    return null
  }
}

module.exports = {
  tokenSign,
  verificarToken
}