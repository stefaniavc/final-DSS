const mongoose = require('mongoose');

const getConnection = async () => {
    try{

        const url = 'mongodb://leonardo-henao:wDXbrCtEzqiBnbhg@ac-wjtdnzf-shard-00-00.034voeo.mongodb.net:27017,ac-wjtdnzf-shard-00-01.034voeo.mongodb.net:27017,ac-wjtdnzf-shard-00-02.034voeo.mongodb.net:27017/app-inventarios?ssl=true&replicaSet=atlas-12k6cw-shard-0&authSource=admin&retryWrites=true&w=majority'

        await mongoose.connect(url);

        console.log('conexion exitosa');

    }catch (error){
        console.log(error);
    }
}

module.exports = {
    getConnection,
}